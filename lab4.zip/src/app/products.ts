export const products = [
  {
    name: 'LAUMOX X35 Дрон',
    price: 8483,
    rating: '5 out of 10',
    description: 'LAUMOX X35 Дрон gps 5G Wi -Fi 4K HD Камера Profissional Квадрокоптер с дистанционным управлением бесщёточным двигателем дроны шарнирный стабилизатор для камеры GoPro полёта 30 минут' ,
     
  },
  {
    name: 'Eachine E520S',
    price: 3327,
    rating: '3 out of 10',
    description: 'Eachine E520S E520 gps FOLLOW ME wifi FPV Квадрокоптер с 4 K/1080 P HD широкоугольная камера Складная Высота удержания прочный Радиоуправляемый Дрон',
  },
  {
    name: 'SJRC F11 PRO',
    price: 8436,
    rating: '7 out of 10',
    description: 'SJRC F11 PRO gps Дрон с Wifi FPV 1080 P/2 K HD камера F11 бесщеточный Квадрокоптер 25 минут время полета складной Дрон Vs SG906',
  },
  {
    name: 'PGYTECH',
    price: 1405,
    rating: '2 out of 10',
    description: 'PGYTECH защита пропеллера для DJI Mavic 2 Drone Propeller протектор для Mavic 2 Pro Zoom Drone аксессуары',
  },
  {
    name: 'Flynova',
    price: 967,
    rating: '1 out of 10',
    description: 'Flynova мини-Дрон светодиодный Летающий вертолет типа НЛО Спиннер Fingertip Upgrade Flight Gyro Drone самолет игрушка для взрослых подарок для детей'
  },
  {
    name: 'SHAREFUNBAY Дрон',
    price: 1304,
    rating: '3 out of 10',
    description: 'SHAREFUNBAY Дрон 4k HD широкоугольная камера 1080P WiFi fpv Дрон двойная камера Квадрокоптер с регулируемой высотой Дрон камера квадракоптер с камерой квадрокоптер квадракоптер квадрокоптер с камерой '
  },
  {
    name: 'Мини-Дрон с камерой',
    price: 1161,
    rating: '3 out of 10',
    description: 'Мини-Дрон с камерой HD складные дроны один ключ возврат FPV Квадрокоптер Следуйте за мной RC вертолет Квадрокоптер детские игрушки'
  },
  {
    name: 'FIMI X8SE Дрон',
    price: 34671,
    description: 'В наличии FIMI X8SE Дрон 4 к 5 км камера Дрон аксессуар комплект 3 оси складной полный набор для сборки дрона RTF с пультом дистанционного управления батареей'
  },
  {
    name: 'Профессиональный Дрон',
    price: 2229,
    description: 'Профессиональный Дрон с 4K вращающейся камерой ESC HD WiFi FPV высота удержания широкий угол RC Квадрокоптер вертолет S32T игрушка VS XY4 E58'
  },
  {
    name: 'Eachine Wizard X220HV 6S FPV',
    price: 12335,
    description: 'Eachine Wizard X220HV 6S FPV гоночный Радиоуправляемый Дрон PNP w/F4 OSD 45A 40CH 600mW Foxeer Arrow Mini Pro камера'
  }
];


/*
Copyright Google LLC. All Rights Reserved.
Use of this source code is governed by an MIT-style license that
can be found in the LICENSE file at http://angular.io/license
*/