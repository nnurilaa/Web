def middle_way(a, b):
  ll = [a[1],b[1]]
  return ll
