def rotate_left3(nums):
  ll = [nums[1],nums[2],nums[0]]
  return ll
