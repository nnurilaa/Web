def near_ten(num):
  if num%10<=2 or num%10>=8:
    return True
  return False
