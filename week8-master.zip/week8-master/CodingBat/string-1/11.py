def left2(str):
  return str[2:]+str[0:2]
