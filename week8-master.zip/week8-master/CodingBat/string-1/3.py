def make_tags(tag, word):
  return "<"+tag+">"+word+"</"+tag+">"
