def make_out_word(out, word):
  return out[0:2]+word+out[2:4]
