def monkey_trouble(a_smile, b_smile):
  if a_smile==b_smile:
    return True
  else:
    return False
