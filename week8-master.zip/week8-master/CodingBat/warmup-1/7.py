def near_hundred(n):
  if n>=90 and n<=110:
    return True
  elif n>=190 and n<=210:
    return True
  else:
    return False
  
