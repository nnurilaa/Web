def string_times(str, n):
  return str*n  
