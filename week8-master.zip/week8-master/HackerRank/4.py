from __future__ import division

if __name__ == '__main__':
    a = int(input())
    b = int(input())
    print(int(a / b))
    print(a / b)