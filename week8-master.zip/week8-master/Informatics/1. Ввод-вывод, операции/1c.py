import math
n = int(input())
k = int(input())
print(int(k / n))