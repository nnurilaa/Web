system = int(input())
student = int(input())

if (system != 1) and (student != 1) or (system == 1) and (student == 1):
    print("YES")
else:
    print("NO")