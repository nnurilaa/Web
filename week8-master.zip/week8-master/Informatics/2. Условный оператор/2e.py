a = int(input())
b = int(input())
max = 0

if a>b:    
      max=a
      print(1)
else:     
      max=b
      print(2)
