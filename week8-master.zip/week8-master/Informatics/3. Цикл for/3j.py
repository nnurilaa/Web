n=100   
i=1   
s=0   
while i<=n:       
    s=i+s       
    i=i+1   
    
print (s)