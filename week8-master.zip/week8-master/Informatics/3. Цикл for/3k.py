n = int(input())
s = 0
i = 1
while i <= n:
    num = int(input())
    s += num
    i += 1
print(s)