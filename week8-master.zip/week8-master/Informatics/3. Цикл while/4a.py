n = int(input())
x = 1
i = 1
while i ** 2 <= n:
    x = i ** 2
    print(x)
    i += 1