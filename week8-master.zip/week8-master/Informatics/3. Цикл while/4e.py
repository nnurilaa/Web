x = int(input())
y = 1
cnt = 0
while y < x:
    y *= 2
    cnt += 1
print(cnt)